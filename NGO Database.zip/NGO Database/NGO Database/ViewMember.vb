﻿Public Class ViewMember
    Private Sub btnBack_Click(sender As Object, e As EventArgs)
        Me.Hide()
        AddMember.Show()
    End Sub

    Private Sub ViewMember_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            ViewMethod("Select * FROM ngo_members", DTGLIST)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If DTGLIST.Rows.GetRowCount(DataGridViewElementStates.Selected) > 0 Then
            UpdateMember.Show()
            UpdateMember.memberID.Text = DTGLIST.CurrentRow.Cells(0).Value.ToString
            UpdateMember.firstname.Text = DTGLIST.CurrentRow.Cells(1).Value.ToString
            UpdateMember.middlename.Text = DTGLIST.CurrentRow.Cells(2).Value.ToString
            UpdateMember.lastname.Text = DTGLIST.CurrentRow.Cells(3).Value.ToString
            UpdateMember.age.Text = DTGLIST.CurrentRow.Cells(7).Value.ToString
            UpdateMember.address.Text = DTGLIST.CurrentRow.Cells(4).Value.ToString
            UpdateMember.emailadd.Text = DTGLIST.CurrentRow.Cells(6).Value.ToString
            UpdateMember.contactnum.Text = DTGLIST.CurrentRow.Cells(5).Value.ToString
            UpdateMember.position.Text = DTGLIST.CurrentRow.Cells(8).Value.ToString
        Else
            MessageBox.Show("Please select Members information to update")
        End If
    End Sub

    Private Sub DTGLIST_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DTGLIST.CellMouseClick
        UpdateMember.memberID.Text = DTGLIST.CurrentRow.Cells(0).Value.ToString
        UpdateMember.firstname.Text = DTGLIST.CurrentRow.Cells(1).Value.ToString
        UpdateMember.middlename.Text = DTGLIST.CurrentRow.Cells(2).Value.ToString
        UpdateMember.lastname.Text = DTGLIST.CurrentRow.Cells(3).Value.ToString
        UpdateMember.age.Text = DTGLIST.CurrentRow.Cells(7).Value.ToString
        UpdateMember.address.Text = DTGLIST.CurrentRow.Cells(4).Value.ToString
        UpdateMember.emailadd.Text = DTGLIST.CurrentRow.Cells(6).Value.ToString
        UpdateMember.contactnum.Text = DTGLIST.CurrentRow.Cells(5).Value.ToString
        UpdateMember.position.Text = DTGLIST.CurrentRow.Cells(8).Value.ToString
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            If DTGLIST.Rows.GetRowCount(DataGridViewElementStates.Selected) > 0 Then
                DeleteMethod("DELETE FROM ngo_members WHERE memberID = '" & DTGLIST.CurrentRow.Cells(0).Value & "'")
                ViewMethod("Select * FROM ngo_members", DTGLIST)
            Else
                MessageBox.Show("Please select Members information to delete")
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub txtboxSearch_OnTextChange(sender As Object, e As EventArgs) Handles txtboxSeach.OnTextChange
        Try
            ViewMethod("Select * FROM ngo_members WHERE firstname LIKE '%" & txtboxSeach.text & "%' OR lastname LIKE '%" & txtboxSeach.text & "%' OR middlename LIKE '%" & txtboxSeach.text & "%'", DTGLIST)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnMembers_Click(sender As Object, e As EventArgs) Handles btnMembers.Click

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Me.Hide()
        AddMember.Show()
    End Sub

    Private Sub DTGLIST_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DTGLIST.CellContentClick

    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        ViewActivities.Show()
        Me.Hide()

    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        MainForm.Show()
        Me.Hide()

    End Sub

    Private Sub btnRecruitment_Click(sender As Object, e As EventArgs) Handles btnRecruitment.Click
        ViewRecruitment.Show()
        Me.Hide()

    End Sub

    Private Sub btnFund_Click(sender As Object, e As EventArgs) Handles btnFund.Click
        ViewFunds.Show()
        Me.Hide()

    End Sub
End Class