﻿Public Class MainForm
    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnMembers_Click(sender As Object, e As EventArgs) Handles btnMembers.Click
        ViewMember.Show()
        Me.Hide()
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        ViewActivities.Show()
        Me.Hide()
    End Sub

    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton4.Click
        ViewFunds.Show()
        Me.Hide()
    End Sub

    Private Sub btnRecruitment_Click(sender As Object, e As EventArgs) Handles btnRecruitment.Click
        ViewRecruitment.Show()
        Me.Hide()

    End Sub
End Class