﻿Imports MySql.Data.MySqlClient
Public Class AddActivities

    Private Sub AddActivities_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadData()

    End Sub

    Sub LoadData()
        Try
            ViewMethod("SELECT * FROM ngo_members", MembersList)

            MembersList.DataSource = dt
            MembersList.DisplayMember = "memberID"
            MembersList.ValueMember = "memberID"

        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Try
            AddMethod("INSERT INTO 	ngo_activities (actName,actLocation,actDetails,actDate,actStatus,actBudget,memberID) VALUES ('" & ActivityName.Text & "','" & Location.Text & "','" & Details.Text & "','" & Format(DatePicker.Value, "yyyy-MM-dd") & "','" & Status.Text & "','" & Budget.Text & "','" & MembersList.Text & "')")
            ActivityName.Text = ""
            Location.Text = ""
            Details.Text = ""
            Status.Text = ""
            Budget.Text = ""
            MembersList.Text = ""
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        MainForm.Show()
        Me.Hide()

    End Sub

    Private Sub btnMembers_Click(sender As Object, e As EventArgs) Handles btnMembers.Click
        ViewMember.Show()
        Me.Hide()

    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        Try
            ViewActivities.Show()
            Me.Hide()
            ViewMethod("Select * FROM ngo_activities", ViewActivities.DTGLIST)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub label2_Click(sender As Object, e As EventArgs) Handles label2.Click

    End Sub

    Private Sub BunifuGradientPanel1_Paint(sender As Object, e As PaintEventArgs) Handles BunifuGradientPanel1.Paint

    End Sub

    Private Sub BunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton3.Click

    End Sub

    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton4.Click

    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click

    End Sub

    Private Sub BunifuGradientPanel2_Paint(sender As Object, e As PaintEventArgs) Handles BunifuGradientPanel2.Paint

    End Sub

    Private Sub panel1_Paint(sender As Object, e As PaintEventArgs) Handles panel1.Paint

    End Sub

    Private Sub Details_TextChanged(sender As Object, e As EventArgs) Handles Details.TextChanged

    End Sub

    Private Sub Location_TextChanged(sender As Object, e As EventArgs) Handles Location.TextChanged

    End Sub

    Private Sub ActivityName_TextChanged(sender As Object, e As EventArgs) Handles ActivityName.TextChanged

    End Sub

    Private Sub label4_Click(sender As Object, e As EventArgs) Handles label4.Click

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Status_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Status.SelectedIndexChanged

    End Sub

    Private Sub MembersList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles MembersList.SelectedIndexChanged

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub DatePicker_onValueChanged(sender As Object, e As EventArgs) Handles DatePicker.onValueChanged

    End Sub

    Private Sub Budget_TextChanged(sender As Object, e As EventArgs) Handles Budget.TextChanged

    End Sub

    Private Sub labelDetails_Click(sender As Object, e As EventArgs) Handles labelDetails.Click

    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub

    Private Sub labelLocation_Click(sender As Object, e As EventArgs) Handles labelLocation.Click

    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click

    End Sub
End Class