﻿Public Class AddFund
    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton4.Click

    End Sub

    Private Sub AddFund_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadData()

    End Sub

    Sub LoadData()
        Try
            ViewMethod("SELECT * FROM ngo_members", MembersList)

            MembersList.DataSource = dt
            MembersList.DisplayMember = "memberID"
            MembersList.ValueMember = "memberID"

        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Try
            AddMethod("INSERT INTO 	ngo_fund (sourceoffund,amount,date,status,memberID) VALUES ('" & SourceofFund.Text & "','" & Amount.Text & "','" & Format(DatePicker.Value, "yyyy-MM-dd") & "','" & Status.Text & "','" & MembersList.Text & "')")
            SourceofFund.Text = ""
            Amount.Text = ""
            Status.Text = ""
            MembersList.Text = ""
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        MainForm.Show()
        Me.Hide()

    End Sub

    Private Sub btnMembers_Click(sender As Object, e As EventArgs) Handles btnMembers.Click
        ViewMember.Show()
        Me.Hide()

    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        ViewActivities.Show()
        Me.Hide()

    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        Try
            ViewFunds.Show()
            Me.Hide()
            ViewMethod("Select * FROM ngo_fund", ViewFunds.DTGLIST)
        Catch ex As Exception

        End Try
    End Sub
End Class