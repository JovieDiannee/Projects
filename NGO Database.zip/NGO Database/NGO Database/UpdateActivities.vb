﻿Public Class UpdateActivities
    Private Sub UpdateActivities_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub MembersList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles MembersList.SelectedIndexChanged

    End Sub

    Private Sub MembersList_MouseClick(sender As Object, e As MouseEventArgs) Handles MembersList.MouseClick
        LoadData()
    End Sub

    Sub LoadData()
        Try
            ViewMethod("SELECT * FROM ngo_members", MembersList)

            MembersList.DataSource = dt
            MembersList.DisplayMember = "memberID"
            MembersList.ValueMember = "memberID"

        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            UpdateMethod("UPDATE ngo_activities SET actName = '" & AddActivities.Text & "',actLocation = '" & Location.Text & "',actDetails = '" & Details.Text & "',actDate = '" & Format(DatePicker.Value, "yyyy-MM-dd") & "', actStatus = '" & Status.Text & "',	actBudget  = '" & Budget.Text & "',	memberID   = '" & MembersList.Text & "' WHERE actID = " & ActID.Text & "")
            Me.Hide()
            ViewMethod("Select * FROM ngo_activities", ViewActivities.DTGLIST)
        Catch ex As Exception

        End Try
    End Sub
End Class