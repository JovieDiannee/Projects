﻿Public Class LoginForm

    Private Sub LoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub label5_Click(sender As Object, e As EventArgs) Handles label5.Click

    End Sub

    Private Sub btnLogIn_Click(sender As Object, e As EventArgs) Handles btnLogIn.Click
        Try
            If txtBoxUserName.Text = "admin" And txtBoxPassword.Text = "admin" Then
                'MessageBox.Show("Welcome! Good Day Administrator")
                Me.Hide()
                MainForm.Show()
            Else
                MessageBox.Show("You are not Authorized to use this application")
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try



    End Sub

    Private Sub GunaButton1_Click(sender As Object, e As EventArgs) 
        MessageBox.Show("Hi")
    End Sub
End Class
