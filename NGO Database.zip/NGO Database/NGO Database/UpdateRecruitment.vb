﻿Public Class UpdateRecruitment
    Private Sub emailadd_TextChanged(sender As Object, e As EventArgs) Handles emailadd.TextChanged

    End Sub

    Private Sub MembersList_MouseClick(sender As Object, e As MouseEventArgs) Handles MembersList.MouseClick
        LoadData()
    End Sub

    Sub LoadData()
        Try
            ViewMethod("SELECT * FROM ngo_members", MembersList)

            MembersList.DataSource = dt
            MembersList.DisplayMember = "memberID"
            MembersList.ValueMember = "memberID"

        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            UpdateMethod("UPDATE ngo_recruitment SET firstname = '" & firstname.Text & "',middlename = '" & middlename.Text & "',lastname = '" & lastname.Text & "',address = '" & address.Text & "',contactnum = '" & contactnum.Text & "',emailadd = '" & emailadd.Text & "' ,age = '" & age.Text & "' ,date = '" & Format(DatePicker.Value, "yyyy-MM-dd") & "',memberID  = '" & MembersList.Text & "' WHERE recID  = " & recID.Text & "")
            Me.Hide()
            ViewMethod("Select * FROM ngo_recruitment", ViewRecruitment.DTGLIST)
        Catch ex As Exception

        End Try
    End Sub
End Class