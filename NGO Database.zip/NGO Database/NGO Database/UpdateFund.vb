﻿Public Class UpdateFund
    Private Sub UpdateFund_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub MembersList_MouseClick(sender As Object, e As MouseEventArgs) Handles MembersList.MouseClick
        LoadData()
    End Sub
    Sub LoadData()
        Try
            ViewMethod("SELECT * FROM ngo_members", MembersList)

            MembersList.DataSource = dt
            MembersList.DisplayMember = "memberID"
            MembersList.ValueMember = "memberID"

        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            UpdateMethod("UPDATE ngo_fund SET sourceoffund = '" & SourceofFund.Text & "',amount = '" & Amount.Text & "',date = '" & Format(DatePicker.Value, "yyyy-MM-dd") & "', status = '" & Status.Text & "',memberID  = '" & MembersList.Text & "' WHERE fundID = " & FundID.Text & "")
            Me.Hide()
            ViewMethod("Select * FROM ngo_fund", ViewFunds.DTGLIST)
        Catch ex As Exception

        End Try
    End Sub
End Class