﻿Public Class ViewFunds
    Private Sub ViewFunds_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            ViewMethod("Select * FROM ngo_fund", DTGLIST)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        MainForm.Show()
        Me.Hide()

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        AddFund.Show()
        Me.Hide()

    End Sub

    Private Sub btnMembers_Click(sender As Object, e As EventArgs) Handles btnMembers.Click
        ViewMember.Show()
        Me.Hide()

    End Sub

    Private Sub btnActivities_Click(sender As Object, e As EventArgs) Handles btnActivities.Click
        ViewActivities.Show()
        Me.Hide()

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If DTGLIST.Rows.GetRowCount(DataGridViewElementStates.Selected) > 0 Then
            DeleteMethod("DELETE FROM ngo_fund WHERE fundID = '" & DTGLIST.CurrentRow.Cells(0).Value & "'")
            ViewMethod("SELECT * FROM ngo_fund", DTGLIST)
        Else
            MessageBox.Show("Please select Members information to delete")
        End If
    End Sub

    Private Sub txtboxSeach_OnTextChange(sender As Object, e As EventArgs) Handles txtboxSeach.OnTextChange
        Try
            ViewMethod("SELECT * FROM ngo_fund WHERE sourceoffund LIKE '%" & txtboxSeach.text & "%'", DTGLIST)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnRecruitment_Click(sender As Object, e As EventArgs) Handles btnRecruitment.Click
        ViewRecruitment.Show()
        Me.Hide()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If DTGLIST.Rows.GetRowCount(DataGridViewElementStates.Selected) > 0 Then
            UpdateFund.Show()
            UpdateFund.FundID.Text = DTGLIST.CurrentRow.Cells(0).Value.ToString
            UpdateFund.SourceofFund.Text = DTGLIST.CurrentRow.Cells(1).Value.ToString
            UpdateFund.Amount.Text = DTGLIST.CurrentRow.Cells(2).Value.ToString
            UpdateFund.DatePicker.Value = DTGLIST.CurrentRow.Cells(3).Value.ToString
            UpdateFund.Status.Text = DTGLIST.CurrentRow.Cells(4).Value.ToString
            UpdateFund.MembersList.Text = DTGLIST.CurrentRow.Cells(5).Value.ToString
        Else
            MessageBox.Show("Please select Members information to update")
        End If
    End Sub

    Private Sub DTGLIST_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DTGLIST.CellMouseClick
        UpdateFund.FundID.Text = DTGLIST.CurrentRow.Cells(0).Value.ToString
        UpdateFund.SourceofFund.Text = DTGLIST.CurrentRow.Cells(1).Value.ToString
        UpdateFund.Amount.Text = DTGLIST.CurrentRow.Cells(2).Value.ToString
        UpdateFund.DatePicker.Value = DTGLIST.CurrentRow.Cells(3).Value.ToString
        UpdateFund.Status.Text = DTGLIST.CurrentRow.Cells(4).Value.ToString
        UpdateFund.MembersList.Text = DTGLIST.CurrentRow.Cells(5).Value.ToString
    End Sub

End Class