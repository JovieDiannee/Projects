﻿Public Class AddRecruitment
    Private Sub AddRecruitment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadData()
    End Sub

    Sub LoadData()
        Try
            ViewMethod("SELECT * FROM ngo_members", MembersList)

            MembersList.DataSource = dt
            MembersList.DisplayMember = "memberID"
            MembersList.ValueMember = "memberID"

        Catch ex As Exception

        End Try
    End Sub
    Private Sub DatePicker_onValueChanged(sender As Object, e As EventArgs) Handles DatePicker.onValueChanged

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            AddMethod("INSERT INTO 	ngo_recruitment (firstname,middlename,lastname,address,contactnum,emailadd,age,date,memberID) VALUES ('" & firstname.Text & "','" & middlename.Text & "','" & lastname.Text & "','" & address.Text & "','" & contactnum.Text & "','" & emailadd.Text & "'," & age.Text & ",'" & Format(DatePicker.Value, "yyyy-MM-dd") & "','" & MembersList.Text & "')")
            firstname.Text = ""
            middlename.Text = ""
            lastname.Text = ""
            address.Text = ""
            contactnum.Text = ""
            emailadd.Text = ""
            age.Text = ""
            MembersList.Text = ""
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        Try
            ViewRecruitment.Show()
            Me.Hide()
            ViewMethod("Select * FROM ngo_recruitment", ViewRecruitment.DTGLIST)
        Catch ex As Exception

        End Try
    End Sub
End Class