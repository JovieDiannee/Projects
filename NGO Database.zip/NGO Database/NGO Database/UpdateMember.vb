﻿Public Class UpdateMember
    Private Sub btnCancel_Click(sender As Object, e As EventArgs)
        Me.Hide()

    End Sub

    'Private Sub btnSave_Click(sender As Object, e As EventArgs)
    'Try
    ' UpdateMethod("UPDATE ngo_members SET Firstname = '" & firstname.Text & "',Middlename = '" & middlename.Text & "',Lastname = '" & lastname.Text & "',Address = '" & address.Text & "',Contactnum = '" & contactnum.Text & "',Emailadd = '" & emailadd.Text & "' ,Age = '" & age.Text & "' ,Position = '" & position.Text & "' WHERE memberID = '" & memberID.Text & "'")
    'Me.Hide()
    ' ViewMethod("Select * FROM ngo_members", ViewMember.DTGLIST)
    'Catch ex As Exception
    '
    'End Try
    'End Sub

    Private Sub btnSave_Click_1(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            UpdateMethod("UPDATE ngo_members SET Firstname = '" & firstname.Text & "',Middlename = '" & middlename.Text & "',Lastname = '" & lastname.Text & "',Address = '" & address.Text & "',Contactnum = '" & contactnum.Text & "',Emailadd = '" & emailadd.Text & "' ,Age = '" & age.Text & "' ,Position = '" & position.Text & "' WHERE memberID = '" & memberID.Text & "'")
            Me.Hide()
            ViewMethod("Select * FROM ngo_members", ViewMember.DTGLIST)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnCancel_Click_1(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Hide()
               
    End Sub

    Private Sub Licensing1_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub UpdateMember_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class