﻿Public Class AddMember
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Try
            AddMethod("INSERT INTO 	ngo_members (memberID,Firstname,Middlename,Lastname,Address,Contactnum,Emailadd,Age,Position) VALUES ('" & memberID.Text & "','" & firstname.Text & "','" & middlename.Text & "','" & lastname.Text & "','" & address.Text & "','" & contactnum.Text & "','" & emailadd.Text & "','" & age.Text & "','" & position.Text & "')")
            memberID.Text = ""
            firstname.Text = ""
            middlename.Text = ""
            lastname.Text = ""
            address.Text = ""
            contactnum.Text = ""
            emailadd.Text = ""
            age.Text = ""
            position.Text = ""
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        Try
            ViewMember.Show()
            Me.Hide()
            ViewMethod("Select * FROM ngo_members", ViewMember.DTGLIST)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        Me.Hide()
        MainForm.Show()
    End Sub

    Private Sub btnMembers_Click(sender As Object, e As EventArgs) Handles btnMembers.Click
        Me.Hide()
        ViewMember.Show()

    End Sub

    Private Sub btnActivity_Click(sender As Object, e As EventArgs) Handles btnActivity.Click
        ViewActivities.Show()
        Me.Hide()

    End Sub

    Private Sub AddMember_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class