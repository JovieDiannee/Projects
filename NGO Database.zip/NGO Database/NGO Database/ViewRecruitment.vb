﻿Public Class ViewRecruitment
    Private Sub ViewRecuitment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            ViewMethod("Select * FROM ngo_recruitment", DTGLIST)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        AddRecruitment.Show()
        Me.Hide()

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If DTGLIST.Rows.GetRowCount(DataGridViewElementStates.Selected) > 0 Then
            DeleteMethod("DELETE FROM ngo_recruitment WHERE recID = '" & DTGLIST.CurrentRow.Cells(0).Value & "'")
            ViewMethod("SELECT * FROM ngo_recruitment", DTGLIST)
        Else
            MessageBox.Show("Please select Members information to delete")
        End If
    End Sub

    Private Sub txtboxSeach_OnTextChange(sender As Object, e As EventArgs) Handles txtboxSeach.OnTextChange
        Try
            ViewMethod("Select * FROM ngo_recruitment WHERE firstname LIKE '%" & txtboxSeach.text & "%' OR lastname LIKE '%" & txtboxSeach.text & "%' OR middlename LIKE '%" & txtboxSeach.text & "%'", DTGLIST)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        MainForm.Show()
        Me.Hide()

    End Sub

    Private Sub DTGLIST_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DTGLIST.CellMouseClick
        UpdateRecruitment.recID.Text = DTGLIST.CurrentRow.Cells(0).Value.ToString
        UpdateRecruitment.firstname.Text = DTGLIST.CurrentRow.Cells(1).Value.ToString
        UpdateRecruitment.middlename.Text = DTGLIST.CurrentRow.Cells(2).Value.ToString
        UpdateRecruitment.lastname.Text = DTGLIST.CurrentRow.Cells(3).Value.ToString
        UpdateRecruitment.address.Text = DTGLIST.CurrentRow.Cells(4).Value.ToString
        UpdateRecruitment.contactnum.Text = DTGLIST.CurrentRow.Cells(5).Value.ToString
        UpdateRecruitment.emailadd.Text = DTGLIST.CurrentRow.Cells(6).Value.ToString
        UpdateRecruitment.age.Text = DTGLIST.CurrentRow.Cells(7).Value.ToString
        UpdateRecruitment.DatePicker.Value = DTGLIST.CurrentRow.Cells(8).Value.ToString
        UpdateRecruitment.MembersList.Text = DTGLIST.CurrentRow.Cells(9).Value.ToString
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If DTGLIST.Rows.GetRowCount(DataGridViewElementStates.Selected) > 0 Then
            UpdateRecruitment.Show()
            UpdateRecruitment.recID.Text = DTGLIST.CurrentRow.Cells(0).Value.ToString
            UpdateRecruitment.firstname.Text = DTGLIST.CurrentRow.Cells(1).Value.ToString
            UpdateRecruitment.middlename.Text = DTGLIST.CurrentRow.Cells(2).Value.ToString
            UpdateRecruitment.lastname.Text = DTGLIST.CurrentRow.Cells(3).Value.ToString
            UpdateRecruitment.address.Text = DTGLIST.CurrentRow.Cells(4).Value.ToString
            UpdateRecruitment.contactnum.Text = DTGLIST.CurrentRow.Cells(5).Value.ToString
            UpdateRecruitment.emailadd.Text = DTGLIST.CurrentRow.Cells(6).Value.ToString
            UpdateRecruitment.age.Text = DTGLIST.CurrentRow.Cells(7).Value.ToString
            UpdateRecruitment.DatePicker.Value = DTGLIST.CurrentRow.Cells(8).Value.ToString
            UpdateRecruitment.MembersList.Text = DTGLIST.CurrentRow.Cells(9).Value.ToString
        Else
            MessageBox.Show("Please select Members information to update")
        End If
    End Sub

    Private Sub btnFund_Click(sender As Object, e As EventArgs) Handles btnFund.Click
        ViewFunds.Show()
        Me.Hide()
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        ViewActivities.Show()
        Me.Hide()

    End Sub

    Private Sub btnMembers_Click(sender As Object, e As EventArgs) Handles btnMembers.Click
        ViewMember.Show()
        Me.Hide()
    End Sub
End Class