﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ViewRecruitment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ViewRecruitment))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.BunifuGradientPanel1 = New ns1.BunifuGradientPanel()
        Me.btnHome = New ns1.BunifuFlatButton()
        Me.btnRecruitment = New ns1.BunifuFlatButton()
        Me.btnFund = New ns1.BunifuFlatButton()
        Me.BunifuFlatButton2 = New ns1.BunifuFlatButton()
        Me.btnMembers = New ns1.BunifuFlatButton()
        Me.BunifuGradientPanel2 = New ns1.BunifuGradientPanel()
        Me.btnAdd = New ns1.BunifuFlatButton()
        Me.txtboxSeach = New ns1.BunifuTextbox()
        Me.btnDelete = New ns1.BunifuFlatButton()
        Me.btnUpdate = New ns1.BunifuFlatButton()
        Me.DTGLIST = New ns1.BunifuCustomDataGrid()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.label2 = New System.Windows.Forms.Label()
        Me.panel1.SuspendLayout()
        Me.BunifuGradientPanel1.SuspendLayout()
        Me.BunifuGradientPanel2.SuspendLayout()
        CType(Me.DTGLIST, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panel1
        '
        Me.panel1.BackColor = System.Drawing.SystemColors.Highlight
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel1.Controls.Add(Me.BunifuGradientPanel1)
        Me.panel1.Controls.Add(Me.BunifuGradientPanel2)
        Me.panel1.Controls.Add(Me.label2)
        Me.panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panel1.Location = New System.Drawing.Point(0, 0)
        Me.panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(1257, 724)
        Me.panel1.TabIndex = 9
        '
        'BunifuGradientPanel1
        '
        Me.BunifuGradientPanel1.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel1.Controls.Add(Me.btnHome)
        Me.BunifuGradientPanel1.Controls.Add(Me.btnRecruitment)
        Me.BunifuGradientPanel1.Controls.Add(Me.btnFund)
        Me.BunifuGradientPanel1.Controls.Add(Me.BunifuFlatButton2)
        Me.BunifuGradientPanel1.Controls.Add(Me.btnMembers)
        Me.BunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.White
        Me.BunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel1.GradientTopRight = System.Drawing.Color.White
        Me.BunifuGradientPanel1.Location = New System.Drawing.Point(11, 71)
        Me.BunifuGradientPanel1.Name = "BunifuGradientPanel1"
        Me.BunifuGradientPanel1.Quality = 10
        Me.BunifuGradientPanel1.Size = New System.Drawing.Size(264, 640)
        Me.BunifuGradientPanel1.TabIndex = 10
        '
        'btnHome
        '
        Me.btnHome.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.btnHome.BackColor = System.Drawing.Color.MidnightBlue
        Me.btnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnHome.BorderRadius = 0
        Me.btnHome.ButtonText = "Home Page"
        Me.btnHome.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnHome.DisabledColor = System.Drawing.Color.Gray
        Me.btnHome.Iconcolor = System.Drawing.Color.Transparent
        Me.btnHome.Iconimage = CType(resources.GetObject("btnHome.Iconimage"), System.Drawing.Image)
        Me.btnHome.Iconimage_right = Nothing
        Me.btnHome.Iconimage_right_Selected = Nothing
        Me.btnHome.Iconimage_Selected = Nothing
        Me.btnHome.IconMarginLeft = 0
        Me.btnHome.IconMarginRight = 0
        Me.btnHome.IconRightVisible = True
        Me.btnHome.IconRightZoom = 0R
        Me.btnHome.IconVisible = True
        Me.btnHome.IconZoom = 90.0R
        Me.btnHome.IsTab = False
        Me.btnHome.Location = New System.Drawing.Point(20, 16)
        Me.btnHome.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Normalcolor = System.Drawing.Color.MidnightBlue
        Me.btnHome.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnHome.OnHoverTextColor = System.Drawing.Color.White
        Me.btnHome.selected = False
        Me.btnHome.Size = New System.Drawing.Size(229, 59)
        Me.btnHome.TabIndex = 11
        Me.btnHome.Text = "Home Page"
        Me.btnHome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnHome.Textcolor = System.Drawing.Color.White
        Me.btnHome.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btnRecruitment
        '
        Me.btnRecruitment.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.btnRecruitment.BackColor = System.Drawing.Color.SeaGreen
        Me.btnRecruitment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnRecruitment.BorderRadius = 0
        Me.btnRecruitment.ButtonText = "Recruitment"
        Me.btnRecruitment.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRecruitment.DisabledColor = System.Drawing.Color.Gray
        Me.btnRecruitment.Iconcolor = System.Drawing.Color.Transparent
        Me.btnRecruitment.Iconimage = CType(resources.GetObject("btnRecruitment.Iconimage"), System.Drawing.Image)
        Me.btnRecruitment.Iconimage_right = Nothing
        Me.btnRecruitment.Iconimage_right_Selected = Nothing
        Me.btnRecruitment.Iconimage_Selected = Nothing
        Me.btnRecruitment.IconMarginLeft = 0
        Me.btnRecruitment.IconMarginRight = 0
        Me.btnRecruitment.IconRightVisible = True
        Me.btnRecruitment.IconRightZoom = 0R
        Me.btnRecruitment.IconVisible = True
        Me.btnRecruitment.IconZoom = 90.0R
        Me.btnRecruitment.IsTab = False
        Me.btnRecruitment.Location = New System.Drawing.Point(20, 302)
        Me.btnRecruitment.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnRecruitment.Name = "btnRecruitment"
        Me.btnRecruitment.Normalcolor = System.Drawing.Color.SeaGreen
        Me.btnRecruitment.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnRecruitment.OnHoverTextColor = System.Drawing.Color.White
        Me.btnRecruitment.selected = False
        Me.btnRecruitment.Size = New System.Drawing.Size(229, 59)
        Me.btnRecruitment.TabIndex = 10
        Me.btnRecruitment.Text = "Recruitment"
        Me.btnRecruitment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnRecruitment.Textcolor = System.Drawing.Color.White
        Me.btnRecruitment.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btnFund
        '
        Me.btnFund.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.btnFund.BackColor = System.Drawing.Color.MidnightBlue
        Me.btnFund.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnFund.BorderRadius = 0
        Me.btnFund.ButtonText = "Fund"
        Me.btnFund.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnFund.DisabledColor = System.Drawing.Color.Gray
        Me.btnFund.Iconcolor = System.Drawing.Color.Transparent
        Me.btnFund.Iconimage = CType(resources.GetObject("btnFund.Iconimage"), System.Drawing.Image)
        Me.btnFund.Iconimage_right = Nothing
        Me.btnFund.Iconimage_right_Selected = Nothing
        Me.btnFund.Iconimage_Selected = Nothing
        Me.btnFund.IconMarginLeft = 0
        Me.btnFund.IconMarginRight = 0
        Me.btnFund.IconRightVisible = True
        Me.btnFund.IconRightZoom = 0R
        Me.btnFund.IconVisible = True
        Me.btnFund.IconZoom = 90.0R
        Me.btnFund.IsTab = False
        Me.btnFund.Location = New System.Drawing.Point(20, 230)
        Me.btnFund.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnFund.Name = "btnFund"
        Me.btnFund.Normalcolor = System.Drawing.Color.MidnightBlue
        Me.btnFund.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnFund.OnHoverTextColor = System.Drawing.Color.White
        Me.btnFund.selected = False
        Me.btnFund.Size = New System.Drawing.Size(229, 59)
        Me.btnFund.TabIndex = 9
        Me.btnFund.Text = "Fund"
        Me.btnFund.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnFund.Textcolor = System.Drawing.Color.White
        Me.btnFund.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton2
        '
        Me.BunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BunifuFlatButton2.BackColor = System.Drawing.Color.MidnightBlue
        Me.BunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton2.BorderRadius = 0
        Me.BunifuFlatButton2.ButtonText = "Activites"
        Me.BunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton2.Iconimage = CType(resources.GetObject("BunifuFlatButton2.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton2.Iconimage_right = Nothing
        Me.BunifuFlatButton2.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton2.Iconimage_Selected = Nothing
        Me.BunifuFlatButton2.IconMarginLeft = 0
        Me.BunifuFlatButton2.IconMarginRight = 0
        Me.BunifuFlatButton2.IconRightVisible = True
        Me.BunifuFlatButton2.IconRightZoom = 0R
        Me.BunifuFlatButton2.IconVisible = True
        Me.BunifuFlatButton2.IconZoom = 90.0R
        Me.BunifuFlatButton2.IsTab = False
        Me.BunifuFlatButton2.Location = New System.Drawing.Point(20, 159)
        Me.BunifuFlatButton2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BunifuFlatButton2.Name = "BunifuFlatButton2"
        Me.BunifuFlatButton2.Normalcolor = System.Drawing.Color.MidnightBlue
        Me.BunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton2.selected = False
        Me.BunifuFlatButton2.Size = New System.Drawing.Size(229, 59)
        Me.BunifuFlatButton2.TabIndex = 8
        Me.BunifuFlatButton2.Text = "Activites"
        Me.BunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton2.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton2.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btnMembers
        '
        Me.btnMembers.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.btnMembers.BackColor = System.Drawing.Color.MidnightBlue
        Me.btnMembers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMembers.BorderRadius = 0
        Me.btnMembers.ButtonText = "Members"
        Me.btnMembers.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMembers.DisabledColor = System.Drawing.Color.Gray
        Me.btnMembers.Iconcolor = System.Drawing.Color.Transparent
        Me.btnMembers.Iconimage = CType(resources.GetObject("btnMembers.Iconimage"), System.Drawing.Image)
        Me.btnMembers.Iconimage_right = Nothing
        Me.btnMembers.Iconimage_right_Selected = Nothing
        Me.btnMembers.Iconimage_Selected = Nothing
        Me.btnMembers.IconMarginLeft = 0
        Me.btnMembers.IconMarginRight = 0
        Me.btnMembers.IconRightVisible = True
        Me.btnMembers.IconRightZoom = 0R
        Me.btnMembers.IconVisible = True
        Me.btnMembers.IconZoom = 90.0R
        Me.btnMembers.IsTab = False
        Me.btnMembers.Location = New System.Drawing.Point(20, 87)
        Me.btnMembers.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnMembers.Name = "btnMembers"
        Me.btnMembers.Normalcolor = System.Drawing.Color.MidnightBlue
        Me.btnMembers.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnMembers.OnHoverTextColor = System.Drawing.Color.White
        Me.btnMembers.selected = False
        Me.btnMembers.Size = New System.Drawing.Size(229, 59)
        Me.btnMembers.TabIndex = 7
        Me.btnMembers.Text = "Members"
        Me.btnMembers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnMembers.Textcolor = System.Drawing.Color.White
        Me.btnMembers.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuGradientPanel2
        '
        Me.BunifuGradientPanel2.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel2.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel2.Controls.Add(Me.btnAdd)
        Me.BunifuGradientPanel2.Controls.Add(Me.txtboxSeach)
        Me.BunifuGradientPanel2.Controls.Add(Me.btnDelete)
        Me.BunifuGradientPanel2.Controls.Add(Me.btnUpdate)
        Me.BunifuGradientPanel2.Controls.Add(Me.DTGLIST)
        Me.BunifuGradientPanel2.GradientBottomLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel2.GradientBottomRight = System.Drawing.Color.White
        Me.BunifuGradientPanel2.GradientTopLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel2.GradientTopRight = System.Drawing.Color.White
        Me.BunifuGradientPanel2.Location = New System.Drawing.Point(282, 72)
        Me.BunifuGradientPanel2.Name = "BunifuGradientPanel2"
        Me.BunifuGradientPanel2.Quality = 10
        Me.BunifuGradientPanel2.Size = New System.Drawing.Size(963, 640)
        Me.BunifuGradientPanel2.TabIndex = 8
        '
        'btnAdd
        '
        Me.btnAdd.Activecolor = System.Drawing.SystemColors.Highlight
        Me.btnAdd.BackColor = System.Drawing.Color.SeaGreen
        Me.btnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnAdd.BorderRadius = 0
        Me.btnAdd.ButtonText = "Add Recruit / Volunteer"
        Me.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAdd.DisabledColor = System.Drawing.Color.Gray
        Me.btnAdd.Iconcolor = System.Drawing.Color.Transparent
        Me.btnAdd.Iconimage = Nothing
        Me.btnAdd.Iconimage_right = Nothing
        Me.btnAdd.Iconimage_right_Selected = Nothing
        Me.btnAdd.Iconimage_Selected = Nothing
        Me.btnAdd.IconMarginLeft = 0
        Me.btnAdd.IconMarginRight = 0
        Me.btnAdd.IconRightVisible = True
        Me.btnAdd.IconRightZoom = 0R
        Me.btnAdd.IconVisible = True
        Me.btnAdd.IconZoom = 90.0R
        Me.btnAdd.IsTab = False
        Me.btnAdd.Location = New System.Drawing.Point(12, 577)
        Me.btnAdd.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Normalcolor = System.Drawing.Color.SeaGreen
        Me.btnAdd.OnHovercolor = System.Drawing.Color.DarkBlue
        Me.btnAdd.OnHoverTextColor = System.Drawing.Color.White
        Me.btnAdd.selected = False
        Me.btnAdd.Size = New System.Drawing.Size(275, 48)
        Me.btnAdd.TabIndex = 36
        Me.btnAdd.Text = "Add Recruit / Volunteer"
        Me.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnAdd.Textcolor = System.Drawing.Color.White
        Me.btnAdd.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'txtboxSeach
        '
        Me.txtboxSeach.BackColor = System.Drawing.Color.White
        Me.txtboxSeach.BackgroundImage = CType(resources.GetObject("txtboxSeach.BackgroundImage"), System.Drawing.Image)
        Me.txtboxSeach.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.txtboxSeach.ForeColor = System.Drawing.SystemColors.Highlight
        Me.txtboxSeach.Icon = CType(resources.GetObject("txtboxSeach.Icon"), System.Drawing.Image)
        Me.txtboxSeach.Location = New System.Drawing.Point(12, 8)
        Me.txtboxSeach.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtboxSeach.Name = "txtboxSeach"
        Me.txtboxSeach.Size = New System.Drawing.Size(939, 41)
        Me.txtboxSeach.TabIndex = 35
        Me.txtboxSeach.text = "Search by Name"
        '
        'btnDelete
        '
        Me.btnDelete.Activecolor = System.Drawing.SystemColors.Highlight
        Me.btnDelete.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnDelete.BorderRadius = 0
        Me.btnDelete.ButtonText = "Delete Information"
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.DisabledColor = System.Drawing.Color.Gray
        Me.btnDelete.Iconcolor = System.Drawing.Color.Transparent
        Me.btnDelete.Iconimage = Nothing
        Me.btnDelete.Iconimage_right = Nothing
        Me.btnDelete.Iconimage_right_Selected = Nothing
        Me.btnDelete.Iconimage_Selected = Nothing
        Me.btnDelete.IconMarginLeft = 0
        Me.btnDelete.IconMarginRight = 0
        Me.btnDelete.IconRightVisible = True
        Me.btnDelete.IconRightZoom = 0R
        Me.btnDelete.IconVisible = True
        Me.btnDelete.IconZoom = 90.0R
        Me.btnDelete.IsTab = False
        Me.btnDelete.Location = New System.Drawing.Point(803, 577)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Normalcolor = System.Drawing.SystemColors.HotTrack
        Me.btnDelete.OnHovercolor = System.Drawing.Color.DarkBlue
        Me.btnDelete.OnHoverTextColor = System.Drawing.Color.White
        Me.btnDelete.selected = False
        Me.btnDelete.Size = New System.Drawing.Size(148, 48)
        Me.btnDelete.TabIndex = 34
        Me.btnDelete.Text = "Delete Information"
        Me.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnDelete.Textcolor = System.Drawing.Color.White
        Me.btnDelete.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btnUpdate
        '
        Me.btnUpdate.Activecolor = System.Drawing.SystemColors.Highlight
        Me.btnUpdate.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btnUpdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnUpdate.BorderRadius = 0
        Me.btnUpdate.ButtonText = "Update Information"
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.DisabledColor = System.Drawing.Color.Gray
        Me.btnUpdate.Iconcolor = System.Drawing.Color.Transparent
        Me.btnUpdate.Iconimage = Nothing
        Me.btnUpdate.Iconimage_right = Nothing
        Me.btnUpdate.Iconimage_right_Selected = Nothing
        Me.btnUpdate.Iconimage_Selected = Nothing
        Me.btnUpdate.IconMarginLeft = 0
        Me.btnUpdate.IconMarginRight = 0
        Me.btnUpdate.IconRightVisible = True
        Me.btnUpdate.IconRightZoom = 0R
        Me.btnUpdate.IconVisible = True
        Me.btnUpdate.IconZoom = 90.0R
        Me.btnUpdate.IsTab = False
        Me.btnUpdate.Location = New System.Drawing.Point(645, 577)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Normalcolor = System.Drawing.SystemColors.HotTrack
        Me.btnUpdate.OnHovercolor = System.Drawing.Color.DarkBlue
        Me.btnUpdate.OnHoverTextColor = System.Drawing.Color.White
        Me.btnUpdate.selected = False
        Me.btnUpdate.Size = New System.Drawing.Size(148, 48)
        Me.btnUpdate.TabIndex = 33
        Me.btnUpdate.Text = "Update Information"
        Me.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnUpdate.Textcolor = System.Drawing.Color.White
        Me.btnUpdate.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'DTGLIST
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.DTGLIST.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DTGLIST.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.DTGLIST.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DTGLIST.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.SkyBlue
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.DarkGreen
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DTGLIST.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DTGLIST.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DTGLIST.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6, Me.Column7, Me.Column8, Me.Column9, Me.Column10})
        Me.DTGLIST.DoubleBuffered = True
        Me.DTGLIST.EnableHeadersVisualStyles = False
        Me.DTGLIST.HeaderBgColor = System.Drawing.Color.SkyBlue
        Me.DTGLIST.HeaderForeColor = System.Drawing.Color.DarkGreen
        Me.DTGLIST.Location = New System.Drawing.Point(12, 56)
        Me.DTGLIST.Name = "DTGLIST"
        Me.DTGLIST.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.DTGLIST.RowHeadersWidth = 51
        Me.DTGLIST.RowTemplate.Height = 24
        Me.DTGLIST.Size = New System.Drawing.Size(939, 500)
        Me.DTGLIST.TabIndex = 1
        '
        'Column1
        '
        Me.Column1.DataPropertyName = "recID"
        Me.Column1.HeaderText = "Recruitment ID"
        Me.Column1.MinimumWidth = 6
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 125
        '
        'Column2
        '
        Me.Column2.DataPropertyName = "firstname"
        Me.Column2.HeaderText = "Firstname"
        Me.Column2.MinimumWidth = 6
        Me.Column2.Name = "Column2"
        Me.Column2.Width = 125
        '
        'Column3
        '
        Me.Column3.DataPropertyName = "middlename"
        Me.Column3.HeaderText = "Middlename"
        Me.Column3.MinimumWidth = 6
        Me.Column3.Name = "Column3"
        Me.Column3.Width = 125
        '
        'Column4
        '
        Me.Column4.DataPropertyName = "lastname"
        Me.Column4.HeaderText = "Lastname"
        Me.Column4.MinimumWidth = 6
        Me.Column4.Name = "Column4"
        Me.Column4.Width = 125
        '
        'Column5
        '
        Me.Column5.DataPropertyName = "address"
        Me.Column5.HeaderText = "Address"
        Me.Column5.MinimumWidth = 6
        Me.Column5.Name = "Column5"
        Me.Column5.Width = 125
        '
        'Column6
        '
        Me.Column6.DataPropertyName = "contactnum"
        Me.Column6.HeaderText = "Contact Number"
        Me.Column6.MinimumWidth = 6
        Me.Column6.Name = "Column6"
        Me.Column6.Width = 125
        '
        'Column7
        '
        Me.Column7.DataPropertyName = "emailadd"
        Me.Column7.HeaderText = "Email Address"
        Me.Column7.MinimumWidth = 6
        Me.Column7.Name = "Column7"
        Me.Column7.Width = 125
        '
        'Column8
        '
        Me.Column8.DataPropertyName = "age"
        Me.Column8.HeaderText = "Age"
        Me.Column8.MinimumWidth = 6
        Me.Column8.Name = "Column8"
        Me.Column8.Width = 125
        '
        'Column9
        '
        Me.Column9.DataPropertyName = "date"
        Me.Column9.HeaderText = "Date"
        Me.Column9.MinimumWidth = 6
        Me.Column9.Name = "Column9"
        Me.Column9.Width = 125
        '
        'Column10
        '
        Me.Column10.DataPropertyName = "memberID"
        Me.Column10.HeaderText = "Incharge ID#"
        Me.Column10.MinimumWidth = 6
        Me.Column10.Name = "Column10"
        Me.Column10.Width = 125
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.BackColor = System.Drawing.SystemColors.Highlight
        Me.label2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.label2.Font = New System.Drawing.Font("Century Gothic", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.ForeColor = System.Drawing.Color.White
        Me.label2.Location = New System.Drawing.Point(268, 12)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(724, 40)
        Me.label2.TabIndex = 6
        Me.label2.Text = "Non-Governmental Organization Database"
        '
        'ViewRecruitment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1257, 724)
        Me.Controls.Add(Me.panel1)
        Me.Name = "ViewRecruitment"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ViewRecuitment"
        Me.panel1.ResumeLayout(False)
        Me.panel1.PerformLayout()
        Me.BunifuGradientPanel1.ResumeLayout(False)
        Me.BunifuGradientPanel2.ResumeLayout(False)
        CType(Me.DTGLIST, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents panel1 As Panel
    Friend WithEvents BunifuGradientPanel1 As ns1.BunifuGradientPanel
    Friend WithEvents btnHome As ns1.BunifuFlatButton
    Friend WithEvents btnRecruitment As ns1.BunifuFlatButton
    Friend WithEvents btnFund As ns1.BunifuFlatButton
    Friend WithEvents BunifuFlatButton2 As ns1.BunifuFlatButton
    Friend WithEvents btnMembers As ns1.BunifuFlatButton
    Friend WithEvents BunifuGradientPanel2 As ns1.BunifuGradientPanel
    Friend WithEvents btnAdd As ns1.BunifuFlatButton
    Friend WithEvents txtboxSeach As ns1.BunifuTextbox
    Friend WithEvents btnDelete As ns1.BunifuFlatButton
    Friend WithEvents btnUpdate As ns1.BunifuFlatButton
    Friend WithEvents DTGLIST As ns1.BunifuCustomDataGrid
    Private WithEvents label2 As Label
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents Column10 As DataGridViewTextBoxColumn
End Class
