﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddActivities
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AddActivities))
        Me.label2 = New System.Windows.Forms.Label()
        Me.btnView = New ns1.BunifuFlatButton()
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.BunifuGradientPanel1 = New ns1.BunifuGradientPanel()
        Me.btnHome = New ns1.BunifuFlatButton()
        Me.BunifuFlatButton3 = New ns1.BunifuFlatButton()
        Me.BunifuFlatButton4 = New ns1.BunifuFlatButton()
        Me.BunifuFlatButton2 = New ns1.BunifuFlatButton()
        Me.btnMembers = New ns1.BunifuFlatButton()
        Me.BunifuGradientPanel2 = New ns1.BunifuGradientPanel()
        Me.btnSubmit = New ns1.BunifuFlatButton()
        Me.Details = New System.Windows.Forms.TextBox()
        Me.Location = New System.Windows.Forms.TextBox()
        Me.ActivityName = New System.Windows.Forms.TextBox()
        Me.label4 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Status = New System.Windows.Forms.ComboBox()
        Me.MembersList = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.DatePicker = New ns1.BunifuDatepicker()
        Me.Budget = New System.Windows.Forms.TextBox()
        Me.labelDetails = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.labelLocation = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.panel1.SuspendLayout()
        Me.BunifuGradientPanel1.SuspendLayout()
        Me.BunifuGradientPanel2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.BackColor = System.Drawing.SystemColors.Highlight
        Me.label2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.label2.Font = New System.Drawing.Font("Century Gothic", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.ForeColor = System.Drawing.Color.White
        Me.label2.Location = New System.Drawing.Point(268, 12)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(724, 40)
        Me.label2.TabIndex = 6
        Me.label2.Text = "Non-Governmental Organization Database"
        '
        'btnView
        '
        Me.btnView.Activecolor = System.Drawing.SystemColors.Highlight
        Me.btnView.BackColor = System.Drawing.Color.Teal
        Me.btnView.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnView.BorderRadius = 0
        Me.btnView.ButtonText = "View Activities"
        Me.btnView.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnView.DisabledColor = System.Drawing.Color.Gray
        Me.btnView.Iconcolor = System.Drawing.Color.Transparent
        Me.btnView.Iconimage = Nothing
        Me.btnView.Iconimage_right = Nothing
        Me.btnView.Iconimage_right_Selected = Nothing
        Me.btnView.Iconimage_Selected = Nothing
        Me.btnView.IconMarginLeft = 0
        Me.btnView.IconMarginRight = 0
        Me.btnView.IconRightVisible = True
        Me.btnView.IconRightZoom = 0R
        Me.btnView.IconVisible = True
        Me.btnView.IconZoom = 90.0R
        Me.btnView.IsTab = False
        Me.btnView.Location = New System.Drawing.Point(340, 543)
        Me.btnView.Margin = New System.Windows.Forms.Padding(5)
        Me.btnView.Name = "btnView"
        Me.btnView.Normalcolor = System.Drawing.Color.Teal
        Me.btnView.OnHovercolor = System.Drawing.Color.DarkBlue
        Me.btnView.OnHoverTextColor = System.Drawing.Color.White
        Me.btnView.selected = False
        Me.btnView.Size = New System.Drawing.Size(279, 48)
        Me.btnView.TabIndex = 29
        Me.btnView.Text = "View Activities"
        Me.btnView.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnView.Textcolor = System.Drawing.Color.White
        Me.btnView.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'panel1
        '
        Me.panel1.BackColor = System.Drawing.SystemColors.Highlight
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel1.Controls.Add(Me.BunifuGradientPanel1)
        Me.panel1.Controls.Add(Me.BunifuGradientPanel2)
        Me.panel1.Controls.Add(Me.label2)
        Me.panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panel1.Location = New System.Drawing.Point(0, 0)
        Me.panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(1257, 724)
        Me.panel1.TabIndex = 7
        '
        'BunifuGradientPanel1
        '
        Me.BunifuGradientPanel1.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel1.Controls.Add(Me.btnHome)
        Me.BunifuGradientPanel1.Controls.Add(Me.BunifuFlatButton3)
        Me.BunifuGradientPanel1.Controls.Add(Me.BunifuFlatButton4)
        Me.BunifuGradientPanel1.Controls.Add(Me.BunifuFlatButton2)
        Me.BunifuGradientPanel1.Controls.Add(Me.btnMembers)
        Me.BunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.White
        Me.BunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel1.GradientTopRight = System.Drawing.Color.White
        Me.BunifuGradientPanel1.Location = New System.Drawing.Point(11, 71)
        Me.BunifuGradientPanel1.Name = "BunifuGradientPanel1"
        Me.BunifuGradientPanel1.Quality = 10
        Me.BunifuGradientPanel1.Size = New System.Drawing.Size(264, 640)
        Me.BunifuGradientPanel1.TabIndex = 7
        '
        'btnHome
        '
        Me.btnHome.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.btnHome.BackColor = System.Drawing.Color.MidnightBlue
        Me.btnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnHome.BorderRadius = 0
        Me.btnHome.ButtonText = "Home Page"
        Me.btnHome.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnHome.DisabledColor = System.Drawing.Color.Gray
        Me.btnHome.Iconcolor = System.Drawing.Color.Transparent
        Me.btnHome.Iconimage = CType(resources.GetObject("btnHome.Iconimage"), System.Drawing.Image)
        Me.btnHome.Iconimage_right = Nothing
        Me.btnHome.Iconimage_right_Selected = Nothing
        Me.btnHome.Iconimage_Selected = Nothing
        Me.btnHome.IconMarginLeft = 0
        Me.btnHome.IconMarginRight = 0
        Me.btnHome.IconRightVisible = True
        Me.btnHome.IconRightZoom = 0R
        Me.btnHome.IconVisible = True
        Me.btnHome.IconZoom = 90.0R
        Me.btnHome.IsTab = False
        Me.btnHome.Location = New System.Drawing.Point(20, 16)
        Me.btnHome.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Normalcolor = System.Drawing.Color.MidnightBlue
        Me.btnHome.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnHome.OnHoverTextColor = System.Drawing.Color.White
        Me.btnHome.selected = False
        Me.btnHome.Size = New System.Drawing.Size(229, 59)
        Me.btnHome.TabIndex = 11
        Me.btnHome.Text = "Home Page"
        Me.btnHome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnHome.Textcolor = System.Drawing.Color.White
        Me.btnHome.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton3
        '
        Me.BunifuFlatButton3.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BunifuFlatButton3.BackColor = System.Drawing.Color.MidnightBlue
        Me.BunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton3.BorderRadius = 0
        Me.BunifuFlatButton3.ButtonText = "Recruitment"
        Me.BunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton3.Iconimage = CType(resources.GetObject("BunifuFlatButton3.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton3.Iconimage_right = Nothing
        Me.BunifuFlatButton3.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton3.Iconimage_Selected = Nothing
        Me.BunifuFlatButton3.IconMarginLeft = 0
        Me.BunifuFlatButton3.IconMarginRight = 0
        Me.BunifuFlatButton3.IconRightVisible = True
        Me.BunifuFlatButton3.IconRightZoom = 0R
        Me.BunifuFlatButton3.IconVisible = True
        Me.BunifuFlatButton3.IconZoom = 90.0R
        Me.BunifuFlatButton3.IsTab = False
        Me.BunifuFlatButton3.Location = New System.Drawing.Point(20, 302)
        Me.BunifuFlatButton3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BunifuFlatButton3.Name = "BunifuFlatButton3"
        Me.BunifuFlatButton3.Normalcolor = System.Drawing.Color.MidnightBlue
        Me.BunifuFlatButton3.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton3.selected = False
        Me.BunifuFlatButton3.Size = New System.Drawing.Size(229, 59)
        Me.BunifuFlatButton3.TabIndex = 10
        Me.BunifuFlatButton3.Text = "Recruitment"
        Me.BunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton3.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton3.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton4
        '
        Me.BunifuFlatButton4.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BunifuFlatButton4.BackColor = System.Drawing.Color.MidnightBlue
        Me.BunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton4.BorderRadius = 0
        Me.BunifuFlatButton4.ButtonText = "Fund"
        Me.BunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton4.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton4.Iconimage = CType(resources.GetObject("BunifuFlatButton4.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton4.Iconimage_right = Nothing
        Me.BunifuFlatButton4.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton4.Iconimage_Selected = Nothing
        Me.BunifuFlatButton4.IconMarginLeft = 0
        Me.BunifuFlatButton4.IconMarginRight = 0
        Me.BunifuFlatButton4.IconRightVisible = True
        Me.BunifuFlatButton4.IconRightZoom = 0R
        Me.BunifuFlatButton4.IconVisible = True
        Me.BunifuFlatButton4.IconZoom = 90.0R
        Me.BunifuFlatButton4.IsTab = False
        Me.BunifuFlatButton4.Location = New System.Drawing.Point(20, 230)
        Me.BunifuFlatButton4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BunifuFlatButton4.Name = "BunifuFlatButton4"
        Me.BunifuFlatButton4.Normalcolor = System.Drawing.Color.MidnightBlue
        Me.BunifuFlatButton4.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton4.selected = False
        Me.BunifuFlatButton4.Size = New System.Drawing.Size(229, 59)
        Me.BunifuFlatButton4.TabIndex = 9
        Me.BunifuFlatButton4.Text = "Fund"
        Me.BunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton4.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton4.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton2
        '
        Me.BunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.BunifuFlatButton2.BackColor = System.Drawing.Color.SeaGreen
        Me.BunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton2.BorderRadius = 0
        Me.BunifuFlatButton2.ButtonText = "Activites"
        Me.BunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton2.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton2.Iconimage = CType(resources.GetObject("BunifuFlatButton2.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton2.Iconimage_right = Nothing
        Me.BunifuFlatButton2.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton2.Iconimage_Selected = Nothing
        Me.BunifuFlatButton2.IconMarginLeft = 0
        Me.BunifuFlatButton2.IconMarginRight = 0
        Me.BunifuFlatButton2.IconRightVisible = True
        Me.BunifuFlatButton2.IconRightZoom = 0R
        Me.BunifuFlatButton2.IconVisible = True
        Me.BunifuFlatButton2.IconZoom = 90.0R
        Me.BunifuFlatButton2.IsTab = False
        Me.BunifuFlatButton2.Location = New System.Drawing.Point(20, 159)
        Me.BunifuFlatButton2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BunifuFlatButton2.Name = "BunifuFlatButton2"
        Me.BunifuFlatButton2.Normalcolor = System.Drawing.Color.SeaGreen
        Me.BunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton2.selected = False
        Me.BunifuFlatButton2.Size = New System.Drawing.Size(229, 59)
        Me.BunifuFlatButton2.TabIndex = 8
        Me.BunifuFlatButton2.Text = "Activites"
        Me.BunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BunifuFlatButton2.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton2.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btnMembers
        '
        Me.btnMembers.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.btnMembers.BackColor = System.Drawing.Color.MidnightBlue
        Me.btnMembers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnMembers.BorderRadius = 0
        Me.btnMembers.ButtonText = "Members"
        Me.btnMembers.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMembers.DisabledColor = System.Drawing.Color.Gray
        Me.btnMembers.Iconcolor = System.Drawing.Color.Transparent
        Me.btnMembers.Iconimage = CType(resources.GetObject("btnMembers.Iconimage"), System.Drawing.Image)
        Me.btnMembers.Iconimage_right = Nothing
        Me.btnMembers.Iconimage_right_Selected = Nothing
        Me.btnMembers.Iconimage_Selected = Nothing
        Me.btnMembers.IconMarginLeft = 0
        Me.btnMembers.IconMarginRight = 0
        Me.btnMembers.IconRightVisible = True
        Me.btnMembers.IconRightZoom = 0R
        Me.btnMembers.IconVisible = True
        Me.btnMembers.IconZoom = 90.0R
        Me.btnMembers.IsTab = False
        Me.btnMembers.Location = New System.Drawing.Point(20, 87)
        Me.btnMembers.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnMembers.Name = "btnMembers"
        Me.btnMembers.Normalcolor = System.Drawing.Color.MidnightBlue
        Me.btnMembers.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnMembers.OnHoverTextColor = System.Drawing.Color.White
        Me.btnMembers.selected = False
        Me.btnMembers.Size = New System.Drawing.Size(229, 59)
        Me.btnMembers.TabIndex = 7
        Me.btnMembers.Text = "Members"
        Me.btnMembers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnMembers.Textcolor = System.Drawing.Color.White
        Me.btnMembers.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuGradientPanel2
        '
        Me.BunifuGradientPanel2.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel2.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel2.Controls.Add(Me.btnSubmit)
        Me.BunifuGradientPanel2.Controls.Add(Me.btnView)
        Me.BunifuGradientPanel2.Controls.Add(Me.Details)
        Me.BunifuGradientPanel2.Controls.Add(Me.Location)
        Me.BunifuGradientPanel2.Controls.Add(Me.ActivityName)
        Me.BunifuGradientPanel2.Controls.Add(Me.label4)
        Me.BunifuGradientPanel2.Controls.Add(Me.GroupBox1)
        Me.BunifuGradientPanel2.GradientBottomLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel2.GradientBottomRight = System.Drawing.Color.White
        Me.BunifuGradientPanel2.GradientTopLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel2.GradientTopRight = System.Drawing.Color.White
        Me.BunifuGradientPanel2.Location = New System.Drawing.Point(282, 72)
        Me.BunifuGradientPanel2.Name = "BunifuGradientPanel2"
        Me.BunifuGradientPanel2.Quality = 10
        Me.BunifuGradientPanel2.Size = New System.Drawing.Size(963, 640)
        Me.BunifuGradientPanel2.TabIndex = 8
        '
        'btnSubmit
        '
        Me.btnSubmit.Activecolor = System.Drawing.SystemColors.Highlight
        Me.btnSubmit.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btnSubmit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnSubmit.BorderRadius = 0
        Me.btnSubmit.ButtonText = "Submit"
        Me.btnSubmit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSubmit.DisabledColor = System.Drawing.Color.Gray
        Me.btnSubmit.Iconcolor = System.Drawing.Color.Transparent
        Me.btnSubmit.Iconimage = Nothing
        Me.btnSubmit.Iconimage_right = Nothing
        Me.btnSubmit.Iconimage_right_Selected = Nothing
        Me.btnSubmit.Iconimage_Selected = Nothing
        Me.btnSubmit.IconMarginLeft = 0
        Me.btnSubmit.IconMarginRight = 0
        Me.btnSubmit.IconRightVisible = True
        Me.btnSubmit.IconRightZoom = 0R
        Me.btnSubmit.IconVisible = True
        Me.btnSubmit.IconZoom = 90.0R
        Me.btnSubmit.IsTab = False
        Me.btnSubmit.Location = New System.Drawing.Point(339, 418)
        Me.btnSubmit.Margin = New System.Windows.Forms.Padding(6, 7, 6, 7)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Normalcolor = System.Drawing.SystemColors.HotTrack
        Me.btnSubmit.OnHovercolor = System.Drawing.Color.DarkBlue
        Me.btnSubmit.OnHoverTextColor = System.Drawing.Color.White
        Me.btnSubmit.selected = False
        Me.btnSubmit.Size = New System.Drawing.Size(279, 52)
        Me.btnSubmit.TabIndex = 31
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnSubmit.Textcolor = System.Drawing.Color.White
        Me.btnSubmit.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Details
        '
        Me.Details.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Details.Location = New System.Drawing.Point(173, 186)
        Me.Details.Multiline = True
        Me.Details.Name = "Details"
        Me.Details.Size = New System.Drawing.Size(742, 31)
        Me.Details.TabIndex = 15
        '
        'Location
        '
        Me.Location.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Location.Location = New System.Drawing.Point(173, 127)
        Me.Location.Multiline = True
        Me.Location.Name = "Location"
        Me.Location.Size = New System.Drawing.Size(742, 31)
        Me.Location.TabIndex = 13
        '
        'ActivityName
        '
        Me.ActivityName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ActivityName.Location = New System.Drawing.Point(173, 69)
        Me.ActivityName.Multiline = True
        Me.ActivityName.Name = "ActivityName"
        Me.ActivityName.Size = New System.Drawing.Size(742, 31)
        Me.ActivityName.TabIndex = 11
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.BackColor = System.Drawing.Color.White
        Me.label4.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.label4.Location = New System.Drawing.Point(29, 75)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(130, 19)
        Me.label4.TabIndex = 10
        Me.label4.Text = "Acvitity Name:"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.White
        Me.GroupBox1.Controls.Add(Me.Status)
        Me.GroupBox1.Controls.Add(Me.MembersList)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.DatePicker)
        Me.GroupBox1.Controls.Add(Me.Budget)
        Me.GroupBox1.Controls.Add(Me.labelDetails)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.labelLocation)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(13, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(934, 491)
        Me.GroupBox1.TabIndex = 30
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Add Activity"
        '
        'Status
        '
        Me.Status.FormattingEnabled = True
        Me.Status.Items.AddRange(New Object() {"New", "Pending", "Done", "Cancelled"})
        Me.Status.Location = New System.Drawing.Point(160, 314)
        Me.Status.Name = "Status"
        Me.Status.Size = New System.Drawing.Size(339, 30)
        Me.Status.TabIndex = 41
        Me.Status.Text = "New"
        '
        'MembersList
        '
        Me.MembersList.BackColor = System.Drawing.Color.White
        Me.MembersList.FormattingEnabled = True
        Me.MembersList.Location = New System.Drawing.Point(651, 312)
        Me.MembersList.Name = "MembersList"
        Me.MembersList.Size = New System.Drawing.Size(251, 30)
        Me.MembersList.TabIndex = 40
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.White
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label6.Location = New System.Drawing.Point(94, 245)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 19)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Date:"
        '
        'DatePicker
        '
        Me.DatePicker.BackColor = System.Drawing.Color.WhiteSmoke
        Me.DatePicker.BorderRadius = 0
        Me.DatePicker.ForeColor = System.Drawing.Color.Black
        Me.DatePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Long]
        Me.DatePicker.FormatCustom = Nothing
        Me.DatePicker.Location = New System.Drawing.Point(160, 236)
        Me.DatePicker.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.DatePicker.Name = "DatePicker"
        Me.DatePicker.Size = New System.Drawing.Size(339, 39)
        Me.DatePicker.TabIndex = 38
        Me.DatePicker.Value = New Date(2022, 5, 21, 16, 52, 46, 947)
        '
        'Budget
        '
        Me.Budget.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Budget.Location = New System.Drawing.Point(651, 241)
        Me.Budget.Multiline = True
        Me.Budget.Name = "Budget"
        Me.Budget.Size = New System.Drawing.Size(251, 31)
        Me.Budget.TabIndex = 35
        '
        'labelDetails
        '
        Me.labelDetails.AutoSize = True
        Me.labelDetails.BackColor = System.Drawing.Color.White
        Me.labelDetails.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelDetails.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.labelDetails.Location = New System.Drawing.Point(78, 181)
        Me.labelDetails.Name = "labelDetails"
        Me.labelDetails.Size = New System.Drawing.Size(68, 19)
        Me.labelDetails.TabIndex = 14
        Me.labelDetails.Text = "Details:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.White
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label8.Location = New System.Drawing.Point(568, 248)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(71, 19)
        Me.Label8.TabIndex = 34
        Me.Label8.Text = "Budget:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.White
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label7.Location = New System.Drawing.Point(86, 318)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 19)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "Status:"
        '
        'labelLocation
        '
        Me.labelLocation.AutoSize = True
        Me.labelLocation.BackColor = System.Drawing.Color.White
        Me.labelLocation.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelLocation.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.labelLocation.Location = New System.Drawing.Point(63, 120)
        Me.labelLocation.Name = "labelLocation"
        Me.labelLocation.Size = New System.Drawing.Size(83, 19)
        Me.labelLocation.TabIndex = 12
        Me.labelLocation.Text = "Location:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.White
        Me.Label9.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label9.Location = New System.Drawing.Point(520, 317)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(120, 19)
        Me.Label9.TabIndex = 36
        Me.Label9.Text = "Incharge ID#:"
        '
        'AddActivities
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1257, 724)
        Me.Controls.Add(Me.panel1)
        Me.Name = "AddActivities"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AddActivities"
        Me.panel1.ResumeLayout(False)
        Me.panel1.PerformLayout()
        Me.BunifuGradientPanel1.ResumeLayout(False)
        Me.BunifuGradientPanel2.ResumeLayout(False)
        Me.BunifuGradientPanel2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents label2 As Label
    Private WithEvents btnView As ns1.BunifuFlatButton
    Private WithEvents panel1 As Panel
    Friend WithEvents BunifuGradientPanel1 As ns1.BunifuGradientPanel
    Friend WithEvents btnHome As ns1.BunifuFlatButton
    Friend WithEvents BunifuFlatButton3 As ns1.BunifuFlatButton
    Friend WithEvents BunifuFlatButton4 As ns1.BunifuFlatButton
    Friend WithEvents BunifuFlatButton2 As ns1.BunifuFlatButton
    Friend WithEvents btnMembers As ns1.BunifuFlatButton
    Friend WithEvents BunifuGradientPanel2 As ns1.BunifuGradientPanel
    Private WithEvents Label6 As Label
    Private WithEvents Details As TextBox
    Private WithEvents labelDetails As Label
    Private WithEvents Location As TextBox
    Private WithEvents labelLocation As Label
    Private WithEvents ActivityName As TextBox
    Private WithEvents label4 As Label
    Private WithEvents btnSubmit As ns1.BunifuFlatButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Status As ComboBox
    Friend WithEvents MembersList As ComboBox
    Friend WithEvents DatePicker As ns1.BunifuDatepicker
    Private WithEvents Budget As TextBox
    Private WithEvents Label8 As Label
    Private WithEvents Label7 As Label
    Private WithEvents Label9 As Label
End Class
