﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class LoginForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LoginForm))
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.label2 = New System.Windows.Forms.Label()
        Me.panel2 = New System.Windows.Forms.Panel()
        Me.bunifuCheckbox1 = New ns1.BunifuCheckbox()
        Me.btnLogIn = New ns1.BunifuFlatButton()
        Me.pictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtBoxPassword = New System.Windows.Forms.TextBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.txtBoxUserName = New System.Windows.Forms.TextBox()
        Me.label4 = New System.Windows.Forms.Label()
        Me.linkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.label3 = New System.Windows.Forms.Label()
        Me.panel1.SuspendLayout()
        Me.panel2.SuspendLayout()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panel1
        '
        Me.panel1.BackColor = System.Drawing.SystemColors.Highlight
        Me.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel1.Controls.Add(Me.label2)
        Me.panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.panel1.Location = New System.Drawing.Point(0, 0)
        Me.panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(1257, 771)
        Me.panel1.TabIndex = 4
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.BackColor = System.Drawing.SystemColors.Highlight
        Me.label2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.label2.Font = New System.Drawing.Font("Century Gothic", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.ForeColor = System.Drawing.Color.White
        Me.label2.Location = New System.Drawing.Point(268, 81)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(724, 40)
        Me.label2.TabIndex = 6
        Me.label2.Text = "Non-Governmental Organization Database"
        '
        'panel2
        '
        Me.panel2.BackColor = System.Drawing.Color.White
        Me.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.panel2.Controls.Add(Me.bunifuCheckbox1)
        Me.panel2.Controls.Add(Me.btnLogIn)
        Me.panel2.Controls.Add(Me.pictureBox1)
        Me.panel2.Controls.Add(Me.txtBoxPassword)
        Me.panel2.Controls.Add(Me.label5)
        Me.panel2.Controls.Add(Me.txtBoxUserName)
        Me.panel2.Controls.Add(Me.label4)
        Me.panel2.Controls.Add(Me.linkLabel1)
        Me.panel2.Controls.Add(Me.label3)
        Me.panel2.Location = New System.Drawing.Point(425, 151)
        Me.panel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panel2.Name = "panel2"
        Me.panel2.Size = New System.Drawing.Size(399, 432)
        Me.panel2.TabIndex = 7
        '
        'bunifuCheckbox1
        '
        Me.bunifuCheckbox1.BackColor = System.Drawing.SystemColors.Desktop
        Me.bunifuCheckbox1.ChechedOffColor = System.Drawing.SystemColors.Desktop
        Me.bunifuCheckbox1.Checked = False
        Me.bunifuCheckbox1.CheckedOnColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.bunifuCheckbox1.ForeColor = System.Drawing.Color.White
        Me.bunifuCheckbox1.Location = New System.Drawing.Point(116, 266)
        Me.bunifuCheckbox1.Margin = New System.Windows.Forms.Padding(5)
        Me.bunifuCheckbox1.Name = "bunifuCheckbox1"
        Me.bunifuCheckbox1.Size = New System.Drawing.Size(20, 20)
        Me.bunifuCheckbox1.TabIndex = 15
        '
        'btnLogIn
        '
        Me.btnLogIn.Activecolor = System.Drawing.SystemColors.Highlight
        Me.btnLogIn.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btnLogIn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnLogIn.BorderRadius = 0
        Me.btnLogIn.ButtonText = "Login"
        Me.btnLogIn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLogIn.DisabledColor = System.Drawing.Color.Gray
        Me.btnLogIn.Iconcolor = System.Drawing.Color.Transparent
        Me.btnLogIn.Iconimage = Nothing
        Me.btnLogIn.Iconimage_right = Nothing
        Me.btnLogIn.Iconimage_right_Selected = Nothing
        Me.btnLogIn.Iconimage_Selected = Nothing
        Me.btnLogIn.IconMarginLeft = 0
        Me.btnLogIn.IconMarginRight = 0
        Me.btnLogIn.IconRightVisible = True
        Me.btnLogIn.IconRightZoom = 0R
        Me.btnLogIn.IconVisible = True
        Me.btnLogIn.IconZoom = 90.0R
        Me.btnLogIn.IsTab = False
        Me.btnLogIn.Location = New System.Drawing.Point(60, 316)
        Me.btnLogIn.Margin = New System.Windows.Forms.Padding(5)
        Me.btnLogIn.Name = "btnLogIn"
        Me.btnLogIn.Normalcolor = System.Drawing.SystemColors.HotTrack
        Me.btnLogIn.OnHovercolor = System.Drawing.Color.DarkBlue
        Me.btnLogIn.OnHoverTextColor = System.Drawing.Color.White
        Me.btnLogIn.selected = False
        Me.btnLogIn.Size = New System.Drawing.Size(279, 48)
        Me.btnLogIn.TabIndex = 14
        Me.btnLogIn.Text = "Login"
        Me.btnLogIn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnLogIn.Textcolor = System.Drawing.Color.White
        Me.btnLogIn.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'pictureBox1
        '
        Me.pictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.pictureBox1.Image = CType(resources.GetObject("pictureBox1.Image"), System.Drawing.Image)
        Me.pictureBox1.Location = New System.Drawing.Point(150, 30)
        Me.pictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(120, 94)
        Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox1.TabIndex = 3
        Me.pictureBox1.TabStop = False
        '
        'txtBoxPassword
        '
        Me.txtBoxPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxPassword.Location = New System.Drawing.Point(150, 201)
        Me.txtBoxPassword.Multiline = True
        Me.txtBoxPassword.Name = "txtBoxPassword"
        Me.txtBoxPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(8226)
        Me.txtBoxPassword.Size = New System.Drawing.Size(185, 31)
        Me.txtBoxPassword.TabIndex = 12
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.label5.Location = New System.Drawing.Point(49, 206)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(87, 19)
        Me.label5.TabIndex = 11
        Me.label5.Text = "Password"
        '
        'txtBoxUserName
        '
        Me.txtBoxUserName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBoxUserName.Location = New System.Drawing.Point(150, 149)
        Me.txtBoxUserName.Multiline = True
        Me.txtBoxUserName.Name = "txtBoxUserName"
        Me.txtBoxUserName.Size = New System.Drawing.Size(185, 31)
        Me.txtBoxUserName.TabIndex = 10
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.label4.Location = New System.Drawing.Point(49, 154)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(91, 19)
        Me.label4.TabIndex = 9
        Me.label4.Text = "Username"
        '
        'linkLabel1
        '
        Me.linkLabel1.AutoSize = True
        Me.linkLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.linkLabel1.LinkColor = System.Drawing.SystemColors.Desktop
        Me.linkLabel1.Location = New System.Drawing.Point(125, 380)
        Me.linkLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.linkLabel1.Name = "linkLabel1"
        Me.linkLabel1.Size = New System.Drawing.Size(134, 18)
        Me.linkLabel1.TabIndex = 7
        Me.linkLabel1.TabStop = True
        Me.linkLabel1.Text = " Create Account "
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.label3.Location = New System.Drawing.Point(151, 266)
        Me.label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(119, 20)
        Me.label3.TabIndex = 3
        Me.label3.Text = "Remember Me"
        '
        'LoginForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1257, 724)
        Me.Controls.Add(Me.panel2)
        Me.Controls.Add(Me.panel1)
        Me.Name = "LoginForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Log In"
        Me.panel1.ResumeLayout(False)
        Me.panel1.PerformLayout()
        Me.panel2.ResumeLayout(False)
        Me.panel2.PerformLayout()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents panel1 As Panel
    Private WithEvents label2 As Label
    Private WithEvents panel2 As Panel
    Private WithEvents pictureBox1 As PictureBox
    Private WithEvents txtBoxPassword As TextBox
    Private WithEvents label5 As Label
    Private WithEvents txtBoxUserName As TextBox
    Private WithEvents label4 As Label
    Private WithEvents linkLabel1 As LinkLabel
    Private WithEvents label3 As Label
    Private WithEvents bunifuCheckbox1 As ns1.BunifuCheckbox
    Private WithEvents btnLogIn As ns1.BunifuFlatButton
End Class
