<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data_transaction extends CI_Model {

	public function get_data() {
		$this->db->select('*');
		$this->db->from('transaction');
		$this->db->join('customer', 'customer.customer_id = transaction.customer_id');
		$this->db->join('employee', 'employee.employee_id = transaction.employee_id');
		$this->db->order_by('transaction_id', 'desc');
		return $this->db->get();
	}

	public function count_rows() {
		return $this->db->count_all('transaction');
	}

	public function count_active() {
		$this->db->select('*');
	    $this->db->from('transaction');
	    $this->db->where('date_finished','0000-00-00');
	    $num_results = $this->db->count_all_results();

	    return $num_results;
	}

	public function get_records($where){
		$this->db->where($where);
		return $this->db->get('transaction');
	}

	public function get_full_records($where){
		$this->db->select('*');
		$this->db->from('transaction');
		$this->db->join('customer', 'customer.customer_id = transaction.customer_id');
		$this->db->join('employee', 'employee.employee_id = transaction.employee_id');
		$this->db->where($where);
		return $this->db->get();
	}

	public function filter($dari, $sampai) {
		return $this->db->query("select * from transaction join employee on transaction.employee_id = employee.employee_id join customer on transaction.customer_id = customer.customer_id where date_finished >= '$dari' and date_finished <= '$sampai'");
	}

	public function insert_data($data, $table){
		$this->db->insert($table, $data);
	}

	public function update_data($where, $data, $table){
		$this->db->where($where);
		return $this->db->replace($table, $data);
	}

	public function delete_data($where, $table){
		$this->db->where($where);
		return $this->db->delete($table);
	}

	public function total_income_year(){
	    $result = $this->db->query("select sum(total) as total_income from transaction where year(date_finished) = year(curdate())")->result();

	    return $result[0]->total_income;
	}
}