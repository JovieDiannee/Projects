<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data_expenses extends CI_Model {

	public function get_data() {
		$this->db->select('*');
		$this->db->from('expenses');
		$this->db->join('employee', 'employee.employee_id = expenses.employee_id');
		return $this->db->get();
	}

	public function count_rows() {
		return $this->db->count_all('expenses');
	}

	public function get_records($where){
		$this->db->where($where);
		return $this->db->get('expenses');
	}

	public function filter($dari, $sampai) {
		return $this->db->query("select * from expenses join employee on expenses.employee_id = employee.employee_id where date_expenses >= '$dari' and date_expenses <= '$sampai'");
	}

	public function insert_data($data, $table){
		$this->db->insert($table, $data);
	}

	public function update_data($where, $data, $table){
		$this->db->where($where);
		return $this->db->replace($table, $data);
	}

	public function delete_data($where, $table){
		$this->db->where($where);
		return $this->db->delete($table);
	}

	public function total_gaji(){
		$result = $this->db->query("select sum(monthly_salary) as total_gaji from employee where active = 1")->result();

	    return $result[0]->total_gaji;
	}

	public function total_spend_year(){
		$result = $this->db->query("select sum(total) as total_expenses from expenses where year(date_expenses) = year(curdate())")->result();

	    return $result[0]->total_expenses;
	}
}