<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Expenses extends CI_Controller {

	function __construct(){
		parent::__construct();
		// cek sesi login
		if ($this->session->userdata('status') != "login") {
			redirect(base_url().'welcome?message=not_logged_in');
		}
		$this->load->library('form_validation');
		$this->load->model('data_expenses');
		$this->load->model('data_employee');
	}

	public function index()
	{
		$user['username'] = $this->session->userdata('username');
		$data['data_expenses'] = $this->data_expenses->get_data()->result();
		$data['data_employee'] = $this->data_employee->get_data()->result();
		$this->load->view('header');
		$this->load->view('navigation', $user);
		$this->load->view('expenses', $data);
		$this->load->view('footer');
		$this->load->view('source');
	}

	public function add()
	{
		$info['datatype'] = 'expenses';
		$info['operation'] = 'Input';
		
		$detail = $this->input->post('detail');
		$total = $this->input->post('total');
		$tgl_expenses = $this->input->post('date_expenses');
		$employee_id = $this->input->post('employee_id');

		$expenses_id = date('YmdHis');

		$this->load->view('header');

		$where = array(
			'expenses_id' => $expenses_id
		);
		$records = $this->data_expenses->get_records($where)->result();

		if (count($records) == 0) {
			$data = array(
				'expenses_id' => $expenses_id,				
				'detail' => $detail,
				'total' => $total,
				'date_expenses' => $tgl_expenses,
				'employee_id' => $employee_id
			);
			$action = $this->data_expenses->insert_data($data,'expenses');
			$this->load->view('notifications/insert_success', $info);	
		} else {
			$this->load->view('notifications/insert_failed', $info);
		}
		$this->load->view('source');	
	}

	// public function bayar_gaji()
	// {
	// 	$info['datatype'] = 'expenses';
	// 	$info['operation'] = 'Input';

	// 	$detail = 'Employee Salary Payment '.date('F Y');
	// 	$total = $this->data_expenses->total_gaji();;
	// 	$tgl_expenses = date('Y-m-d');
	// 	$employee_id = 'K000'; //Bu Rindu

	// 	$expenses_id = date('YmdHis');

	// 	$this->load->view('header');

	// 	$where = array(
	// 		'expenses_id' => $expenses_id
	// 	);
	// 	$records = $this->data_expenses->get_records($where)->result();

	// 	if (count($records) == 0) {
	// 		$data = array(
	// 			'expenses_id' => $expenses_id,				
	// 			'detail' => $detail,
	// 			'total' => $total,
	// 			'date_expenses' => $date_expenses,
	// 			'employee_id' => $employee_id
	// 		);
	// 		$action = $this->data_expenses->insert_data($data,'expenses');
	// 		$this->load->view('notifications/insert_success', $info);	
	// 	} else {
	// 		$this->load->view('notifications/insert_failed', $info);
	// 	}
	// 	$this->load->view('source');	
	// }

	public function edit()
	{
		$info['datatype'] = 'expenses';
		$info['operation'] = 'Ubah';
		
		$expenses_id = $this->input->post('expenses_id');
		$detail = $this->input->post('detail');
		$total = $this->input->post('total');
		$date_expenses = $this->input->post('date_expenses');
		$employee_id = $this->input->post('employee_id');

		$this->load->view('header');

		$where = array(
			'expenses_id' => $expenses_id
		);
		$data = array(
			'expenses_id' => $expenses_id,				
			'detail' => $detail,
			'total' => $total,
			'date_expenses' => $date_expenses,
			'employee_id' => $employee_id
		);
		$action = $this->data_expenses->update_data($where, $data,'expenses');

		if ($action) {
			$this->load->view('notifications/insert_success', $info);
		} else {
			$this->load->view('notifications/insert_failed', $info);
		}

			
		$this->load->view('source');	
	}

	public function delete()
	{
		$info['datatype'] = 'expenses';

		$expenses_id = $this->uri->segment('3');

		$where = array(
			'expenses_id' => $expenses_id
		);

		$this->load->view('header');

		$action = $this->data_expenses->delete_data($where, 'expenses');
		if ($action) {
			$this->load->view('notifications/delete_success', $info);
		} else {
			$this->load->view('notifications/delete_failed', $info);
		}

		$this->load->view('source');
	}

	public function report()
	{
		$user['username'] = $this->session->userdata('username');
		$this->load->view('header');
		$this->load->view('navigation', $user);
		$this->load->view('report/report_filter_expenses');
		$this->load->view('footer');
		$this->load->view('source');
	}

	public function report_filter()
	{
		$user['username'] = $this->session->userdata('username');

		$dari = $this->input->post('dari');
		$sampai = $this->input->post('sampai');

		$data['data_expenses'] = $this->data_expenses->filter($dari, $sampai)->result();

		$this->load->view('header');
		$this->load->view('navigation', $user);
		$this->load->view('report/report_expenses', $data);
		$this->load->view('footer');
		$this->load->view('source');
	}

	function print() {	

		$dari = $this->uri->segment('3');
		$sampai = $this->uri->segment('4');

		$data['dari'] = $dari;
		$data['sampai'] = $sampai;
		$data['data_expenses'] = $this->data_expenses->filter($dari, $sampai)->result();
		
		$this->load->view('print/expenses', $data);
	}

	function cetak_pdf() {
		$this->load->library('dompdf_gen');
		
		$dari = $this->uri->segment('3');
		$sampai = $this->uri->segment('4');

		$data['dari'] = $dari;
		$data['sampai'] = $sampai;
		$data['data_expenses'] = $this->data_expenses->filter($dari, $sampai)->result();
		
		$this->load->view('pdf/expenses', $data);
		
		$paper_size = 'A4';
		$orientation = 'landscape';
		$html = $this->output->get_output();
		$this->dompdf->set_paper($paper_size, $orientation);

		$this->dompdf->load_html($html);
		$this->dompdf->render();
		$this->dompdf->stream("Expenses_Data.pdf", array('Attachment'=>0));
	}
}
