<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {

	function __construct(){
		parent::__construct();
		// cek sesi login
		if ($this->session->userdata('status') != "login") {
			redirect(base_url().'welcome?message=not_logged_in');
		};
		$this->load->library('form_validation');
		$this->load->model('data_employee');
	}

	public function index()
	{
		$user['username'] = $this->session->userdata('username');
		$data['data_employee'] = $this->data_employee->get_data()->result();
		$this->load->view('header');
		$this->load->view('navigation', $user);
		$this->load->view('employee', $data);
		$this->load->view('footer');
		$this->load->view('source');
	}

	public function add()
	{
		$info['datatype'] = 'employee';
		$info['operation'] = 'Input';
		
		$employee_id = $this->input->post('employee_id');
		$name_employee = $this->input->post('name_employee');
		$gender = $this->input->post('gender');
		$address = $this->input->post('address');
		$phone_number = $this->input->post('phone_number');
		$monthly_salary = $this->input->post('monthly_salary');
		$join_date = $this->input->post('join_date');
		$stop_date = $this->input->post('stop_date');

		$active = 0;

		if ($stop_date == null) {
			$active = 1;
		}

		$this->load->view('header');

		$records = $this->data_employee->get_records($employee_id)->result();
		if (count($records) == 0) {
			$data = array(
				'employee_id' => $employee_id,
				'name_employee' => $name_employee,
				'gender' => $gender,
				'address' => $address,
				'phone_number' => $phone_number,
				'monthly_salary' => $monthly_salary,
				'join_date' => $join_date,
				'stop_date' => $stop_date,
				'active' => $active
			);
			$action = $this->data_employee->insert_data($data,'employee');
			$this->load->view('notifications/insert_success', $info);	
		} else {
			$this->load->view('notifications/insert_failed', $info);
		}
		$this->load->view('source');	
	}

	public function edit()
	{
		$info['datatype'] = 'employee';
		$info['operation'] = 'Ubah';
		
		$employee_id = $this->input->post('employee_id');
		$name_employee = $this->input->post('name_employee');
		$gender = $this->input->post('gender');
		$address = $this->input->post('address');
		$phone_number = $this->input->post('phone_number');
		$monthly_salary = $this->input->post('monthly_salary');
		$join_date = $this->input->post('join_date');
		$stop_date = $this->input->post('stop_date');

		$active = 0;

		if ($stop_date == null) {
			$active = 1;
		}

		$this->load->view('header');

		$data = array(
			'employee_id' => $employee_id,
			'name_employee' => $name_employee,
			'gender' => $gender,
			'address' => $address,
			'phone_number' => $phone_number,
			'monthly_salary' => $monthly_salary,
			'join_date' => $join_date,
			'stop_date' => $stop_date,
			'active' => $active
		);
		$action = $this->data_employee->update_data($employee_id, $data,'employee');

		if ($action) {
			$this->load->view('notifications/insert_success', $info);
		} else {
			$this->load->view('notifications/insert_failed', $info);
		}

		$this->load->view('source');	
	}

	public function delete()
	{
		$info['datatype'] = 'employee';

		$employee_id = $this->uri->segment('3');

		$this->load->view('header');

		$action = $this->data_employee->delete_data($employee_id, 'employee');
		if ($action) {
			$this->load->view('notifications/delete_success', $info);
		} else {
			$this->load->view('notifications/delete_failed', $info);
		}

		$this->load->view('source');
	}

	public function report()
	{
		$user['username'] = $this->session->userdata('username');
		$this->load->view('header');
		$this->load->view('navigation', $user);
		$this->load->view('report/report_filter_employee');
		$this->load->view('footer');
		$this->load->view('source');
	}

	public function report_filter()
	{
		$user['username'] = $this->session->userdata('username');

		$dari = $this->input->post('dari');
		$sampai = $this->input->post('sampai');

		$data['data_employee'] = $this->data_employee->filter($dari, $sampai)->result();

		$this->load->view('header');
		$this->load->view('navigation', $user);
		$this->load->view('report/report_employee', $data);
		$this->load->view('footer');
		$this->load->view('source');
	}

	function print() {	

		$dari = $this->uri->segment('3');
		$sampai = $this->uri->segment('4');

		$data['dari'] = $dari;
		$data['sampai'] = $sampai;
		$data['data_employee'] = $this->data_employee->filter($dari, $sampai)->result();
		
		$this->load->view('print/employee', $data);
	}

	function cetak_pdf() {
		$this->load->library('dompdf_gen');
		
		$dari = $this->uri->segment('3');
		$sampai = $this->uri->segment('4');

		$data['dari'] = $dari;
		$data['sampai'] = $sampai;
		$data['data_employee'] = $this->data_employee->filter($dari, $sampai)->result();
		
		$this->load->view('pdf/employee', $data);
		
		$paper_size = 'A4';
		$orientation = 'landscape';
		$html = $this->output->get_output();
		$this->dompdf->set_paper($paper_size, $orientation);

		$this->dompdf->load_html($html);
		$this->dompdf->render();
		$this->dompdf->stream("Employee_Data.pdf", array('Attachment'=>0));
	}
}
