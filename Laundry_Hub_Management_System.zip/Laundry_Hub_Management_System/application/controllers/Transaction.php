<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaction extends CI_Controller {

	function __construct(){
		parent::__construct();
		// cek sesi login
		if ($this->session->userdata('status') != "login") {
			redirect(base_url().'welcome?message=not_logged_in');
		};
		$this->load->library('form_validation');
		$this->load->model('data_transaction');
		$this->load->model('data_customer');
		$this->load->model('data_employee');
	}

	public function index()
	{
		$user['username'] = $this->session->userdata('username');
		$data['data_transaction'] = $this->data_transaction->get_data()->result();
		$data['data_customer'] = $this->data_customer->get_data()->result();
		$data['data_employee'] = $this->data_employee->get_data()->result();
		$this->load->view('header');
		$this->load->view('navigation', $user);
		$this->load->view('transaction', $data);
		$this->load->view('footer');
		$this->load->view('source');
	}

	public function add()
	{
		$info['datatype'] = 'transaction';
		$info['operation'] = 'Input';
		
		$customer_id = $this->input->post('customer_id');
		$employee_id = $this->input->post('employee_id');
		$heavy = $this->input->post('heavy');
		$tgl_order = $this->input->post('date_order');
		$tgl_selesai = $this->input->post('date_finished');

		date_default_timezone_set("Asia/Jakarta");
		$transaction_id = date('YmdHis');
		$total = $heavy * 18.75;

		$this->load->view('header');

		$where = array(
			'transaction_id' => $transaction_id
		);
		$records = $this->data_transaction->get_records($where)->result();

		if (count($records) == 0) {
			$data = array(
				'transaction_id' => $transaction_id,
				'customer_id' => $customer_id,
				'employee_id' => $employee_id,
				'heavy' => $heavy,
				'total' => $total,
				'date_order' => $tgl_order,
				'date_finished' => $tgl_selesai
			);
			$action = $this->data_transaction->insert_data($data,'transaction');
			$this->load->view('notifications/insert_success', $info);	
		} else {
			$this->load->view('notifications/insert_failed', $info);
		}
		$this->load->view('source');	
	}

	public function edit()
	{
		$info['datatype'] = 'transaction';
		$info['operation'] = 'Ubah';
		
		$transaction_id = $this->input->post('transaction_id');
		$customer_id = $this->input->post('customer_id');
		$employee_id = $this->input->post('employee_id');
		$heavy = $this->input->post('heavy');
		$tgl_order = $this->input->post('tgl_order');
		$tgl_selesai = $this->input->post('tgl_selesai');

		$total = $heavy * 18.75;

		$this->load->view('header');

		$where = array(
			'transaction_id' => $transaction_id
		);
		$data = array(
			'transaction_id' => $transaction_id,
			'customer_id' => $customer_id,
			'employee_id' => $employee_id,
			'heavy' => $heavy,
			'total' => $total,
			'date_order' => $tgl_order,
			'date_finished' => $tgl_selesai
		);
		$action = $this->data_transaction->update_data($where, $data,'transaction');

		if ($action) {
			$this->load->view('notifications/insert_success', $info);
		} else {
			$this->load->view('notifications/insert_failed', $info);
		}

			
		$this->load->view('source');	
	}

	public function done()
	{
		$info['datatype'] = 'transaction';
		$info['operation'] = 'Ubah';
		
		$transaction_id = $this->uri->segment('3');
		$tgl_selesai = date('Y-m-d'); //Tambahkan tgl selesai order

		$action = $this->db->query("update transaction set date_finished = '$tgl_selesai' where transaction_id = '$transaction_id'");

		$this->load->view('header');
		if ($action) {
			$this->load->view('notifications/insert_success', $info);
		} else {
			$this->load->view('notifications/insert_failed', $info);
		}	
		$this->load->view('source');	
	}

	public function delete()
	{
		$info['datatype'] = 'transaction';

		$transaction_id = $this->uri->segment('3');

		$where = array(
			'transaction_id' => $transaction_id
		);

		$this->load->view('header');

		$action = $this->data_transaction->delete_data($where, 'transaction');
		if ($action) {
			$this->load->view('notifications/delete_success', $info);
		} else {
			$this->load->view('notifications/delete_failed', $info);
		}

		$this->load->view('source');
	}

	public function report()
	{
		$user['username'] = $this->session->userdata('username');
		$this->load->view('header');
		$this->load->view('navigation', $user);
		$this->load->view('report/report_filter_transaction');
		$this->load->view('footer');
		$this->load->view('source');
	}

	public function report_filter()
	{
		$user['username'] = $this->session->userdata('username');

		$dari = $this->input->post('dari');
		$sampai = $this->input->post('sampai');

		$data['data_transaction'] = $this->data_transaction->filter($dari, $sampai)->result();

		$this->load->view('header');
		$this->load->view('navigation', $user);
		$this->load->view('report/report_transaction', $data);
		$this->load->view('footer');
		$this->load->view('source');
	}

	function print() {	

		$dari = $this->uri->segment('3');
		$sampai = $this->uri->segment('4');

		$data['dari'] = $dari;
		$data['sampai'] = $sampai;
		$data['data_transaction'] = $this->data_transaction->filter($dari, $sampai)->result();
		
		$this->load->view('print/transaction', $data);
	}

	function print_nota() {	

		$transaction_id = $this->uri->segment('3');

		$where = array(
			'transaction_id' => $transaction_id
		);
		$data['data_transaction'] = $this->data_transaction->get_full_records($where)->result();
		
		$this->load->view('print/print_transaction', $data);
	}

	function cetak_pdf() {
		$this->load->library('dompdf_gen');
		
		$dari = $this->uri->segment('3');
		$sampai = $this->uri->segment('4');

		$data['dari'] = $dari;
		$data['sampai'] = $sampai;
		$data['data_transaction'] = $this->data_transaction->filter($dari, $sampai)->result();
		
		$this->load->view('pdf/transaction', $data);
		
		$paper_size = 'A4';
		$orientation = 'landscape';
		$html = $this->output->get_output();
		$this->dompdf->set_paper($paper_size, $orientation);

		$this->dompdf->load_html($html);
		$this->dompdf->render();
		$this->dompdf->stream("Transaction_Detail.pdf", array('Attachment'=>0));
	}
}
