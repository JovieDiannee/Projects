-- phpMyAdmin SQL Dump
-- version 5.3.0-dev+20230109.7cde53ed0d
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: May 30, 2023 at 03:49 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laundrycim`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `customer_id` char(150) NOT NULL,
  `name_customer` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `phone_number` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `customer_id`, `name_customer`, `gender`, `address`, `phone_number`) VALUES
(16, 'P000', 'Jayson Cabrera', 'Male', 'Paterno St Tacloban City', '09876543212'),
(20, 'P001', 'lai bcln', 'Female', 'basey,samar', '09061170194'),
(21, 'P002', 'Sheilla Mae Cubilla', 'Female', 'Tacloban city', '09072764839'),
(22, 'P003', 'Sheena Marie Aguilos', 'Female', 'Hilongos, Leyte', '09503444999'),
(23, 'P004', 'Patrick Quiminales', 'Male', 'Samar', '09312659293'),
(24, 'P005', 'Beboy', 'Male', 'Brgy Rawis Samar', '09741254123'),
(25, 'P006', 'Akira Capoquian', 'Female', 'Palo, Leyte', '09541265202'),
(26, 'P007', 'Windell Urmeneta', 'Female', 'Carigara, Leyte', '09234567893'),
(28, 'P008', 'Marilou Palis', 'Female', 'Caibaan Tacloban City', '09302135711'),
(29, 'P009', 'Amir', 'Male', 'Basey Samar', '09132413567');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` char(6) NOT NULL,
  `name_employee` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `monthly_salary` int(11) NOT NULL,
  `join_date` date NOT NULL,
  `stop_date` date NOT NULL,
  `active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `name_employee`, `gender`, `address`, `phone_number`, `monthly_salary`, `join_date`, `stop_date`, `active`) VALUES
('K000', 'Jovelyn Dianne Gayo', 'Female', '179 Brgy. Paterno St. Tacloban City', '09302133718', 0, '2018-01-01', '0000-00-00', 2),
('K001', 'Jasper L Quimilanes', 'Male', 'Marabut, Samar', '09873842350', 7800, '2023-05-06', '0000-00-00', 1),
('K0010', 'Faith Uy', 'Female', 'Caibaan Tacloban City', '09302135711', 5800, '2023-05-01', '0000-00-00', 1),
('K007', 'Rachelle Kristine Gadil', 'Female', 'Quarry Tacloban City', '09123456789', 10000, '2023-05-29', '0000-00-00', 1),
('K008', 'Winalyn Bachao', 'Female', 'Tacloban City', '098764345678', 9000, '2023-05-28', '0000-00-00', 1),
('K009', 'Laica Lorena Llanda Bacleaan', 'Female', 'Basey, samar', '09061170194', 4, '2023-05-01', '0000-00-00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `expenses_id` varchar(14) NOT NULL,
  `total` int(11) NOT NULL,
  `detail` varchar(100) NOT NULL,
  `date_expenses` date NOT NULL,
  `employee_id` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`expenses_id`, `total`, `detail`, `date_expenses`, `employee_id`) VALUES
('20230529183024', 10000, 'Salary for the month of May 2023', '2023-05-30', 'K007'),
('20230529225219', 5000, 'Bills', '2023-05-29', 'K008'),
('20230529231259', 100, 'Transporation', '2023-05-25', 'K007');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` varchar(14) NOT NULL,
  `customer_id` char(7) NOT NULL,
  `employee_id` char(6) NOT NULL,
  `heavy` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date_order` date NOT NULL,
  `date_finished` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `customer_id`, `employee_id`, `heavy`, `total`, `date_order`, `date_finished`) VALUES
('20230530000223', 'P000', 'K007', 7, 131, '2023-05-30', '2023-05-30'),
('20230530041503', 'P001', 'K009', 10, 188, '2023-05-29', '2023-05-29'),
('20230530041900', 'P002', 'K008', 30, 563, '2023-05-29', '2023-05-30'),
('20230530064117', 'P003', 'K008', 8, 150, '2023-05-26', '2023-05-27'),
('20230530064159', 'P000', 'K007', 8, 150, '2023-05-30', '0000-00-00'),
('20230530065511', 'P001', 'K009', 6, 113, '2023-05-30', '2023-05-30'),
('20230530065700', 'P004', 'K007', 6, 113, '2023-05-26', '0000-00-00'),
('20230530065717', 'P000', 'K001', 10, 188, '2023-05-24', '2023-05-30'),
('20230530070053', 'P005', 'K007', 8, 150, '2023-05-29', '0000-00-00'),
('20230530070109', 'P003', 'K009', 8, 150, '2023-05-24', '2023-05-30'),
('20230530070216', 'P003', 'K001', 11, 206, '2023-05-22', '2023-05-30'),
('20230530070228', 'P000', 'K008', 22, 413, '2023-05-26', '2023-05-30'),
('20230530070256', 'P006', 'K008', 28, 525, '2023-05-26', '2023-05-30'),
('20230530082053', 'P005', 'K001', 8, 150, '2023-05-12', '2023-05-30');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` char(4) NOT NULL,
  `nameuser` varchar(30) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `level` char(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `nameuser`, `username`, `password`, `level`) VALUES
('U001', 'Liam Moore', 'admin', 'D00F5D5217896FB7FD601412CB890830', 'superuser');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`),
  ADD UNIQUE KEY `UNIQUE` (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`expenses_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
